package hello;

public interface IGreeting {
	void sayHello();
}
