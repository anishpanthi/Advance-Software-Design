package products;

public interface IInventoryService {
	
	public int getNumberInStock(int productNumber);	

}
